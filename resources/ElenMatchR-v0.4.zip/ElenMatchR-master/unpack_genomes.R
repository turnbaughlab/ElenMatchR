#unpack_genomes.R
#convert RDS files to familiar fasta and tabular annotation formats
#30Apr2018 JB
#Requires Biostrings package

library(Biostrings)
dir.create("genomes")
for(genome in list.files("resources/RDS/scaffolds", full.names=T)){
message("Unpacking ", genome) 
g<-readRDS(genome)
writeXStringSet(g, paste0("genomes/", gsub("..+/","", gsub("\\.RDS","", genome))))
}

for(genome in list.files("resources/RDS/gtfs/", full.names=T)){
  message("Unpacking ", genome) 
  g<-readRDS(genome)
  write.table(g, paste0("genomes/", gsub("..+/","", gsub("\\.RDS","", genome))), row.names = F, sep="\t", quote=F)
}
